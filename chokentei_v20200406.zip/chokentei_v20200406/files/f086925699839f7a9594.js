function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * コンバータ機能を提供するクラス。
       */

      var Converter =
      /** @class */
      function () {
        function Converter() {}
        /**
         * エンティティをホバー可能に変換する。
         */


        Converter.asHoverable = function (e, opts) {
          var hoverableE = e;
          hoverableE.hoverable = true;
          hoverableE.touchable = true;
          hoverableE.hovered = hoverableE.hovered || new g.Trigger();
          hoverableE.unhovered = hoverableE.unhovered || new g.Trigger();

          if (opts) {
            if (opts.cursor) hoverableE.cursor = opts.cursor;
          }

          return hoverableE;
        };
        /**
         * エンティティのホバーを解除する。
         */


        Converter.asUnhoverable = function (e) {
          var hoverableE = e;
          delete hoverableE.hoverable;

          if (hoverableE.hovered && !hoverableE.hovered.destroyed()) {
            hoverableE.hovered.destroy();
            delete hoverableE.hovered;
          }

          if (hoverableE.unhovered && !hoverableE.unhovered.destroyed()) {
            hoverableE.unhovered.fire();
            hoverableE.unhovered.destroy();
            delete hoverableE.unhovered;
          }

          return hoverableE;
        };

        return Converter;
      }();

      exports.Converter = Converter;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * ホバー機能を提供するプラグイン。
       */

      var HoverPlugin =
      /** @class */
      function () {
        function HoverPlugin(game, view, option) {
          if (option === void 0) {
            option = {};
          }

          this.game = game;
          this.view = view.view;
          this.beforeHover = null;
          this.operationTrigger = new g.Trigger();
          this._cursor = option.cursor || "pointer";
          this._showTooltip = !!option.showTooltip;
          this._getScale = view.getScale ? function () {
            return view.getScale();
          } : null;
          this._onMouseMove_bound = this._onMouseMove.bind(this);
          this._onMouseOut_bound = this._onMouseOut.bind(this);
        }

        HoverPlugin.isSupported = function () {
          return typeof document !== "undefined" && typeof document.addEventListener === "function";
        };

        HoverPlugin.prototype.start = function () {
          this.view.addEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.addEventListener("mouseout", this._onMouseOut_bound, false);
          return true;
        };

        HoverPlugin.prototype.stop = function () {
          this.view.removeEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.removeEventListener("mouseout", this._onMouseOut_bound, false);
        };

        HoverPlugin.prototype._onMouseMove = function (e) {
          var scene = this.game.scene();
          if (!scene) return;
          var rect = this.view.getBoundingClientRect();
          var positionX = rect.left + window.pageXOffset;
          var positionY = rect.top + window.pageYOffset;
          var offsetX = e.pageX - positionX;
          var offsetY = e.pageY - positionY;
          var scale = {
            x: 1,
            y: 1
          };

          if (this._getScale) {
            scale = this._getScale();
          }

          var point = {
            x: offsetX / scale.x,
            y: offsetY / scale.y
          };
          var target = scene.findPointSourceByPoint(point).target;

          if (target && target.hoverable) {
            if (target !== this.beforeHover) {
              if (this.beforeHover && this.beforeHover.hoverable) {
                this._onUnhovered(target);
              }

              this._onHovered(target);
            }

            this.beforeHover = target;
          } else if (this.beforeHover) {
            this._onUnhovered(this.beforeHover);
          }
        };

        HoverPlugin.prototype._onHovered = function (target) {
          if (target.hoverable) {
            this.view.style.cursor = target.cursor ? target.cursor : this._cursor;

            if (this._showTooltip && target.title) {
              this.view.setAttribute("title", target.title);
            }

            target.hovered.fire();
          }
        };

        HoverPlugin.prototype._onUnhovered = function (target) {
          this.view.style.cursor = "auto";

          if (this.beforeHover && this.beforeHover.unhovered) {
            this.beforeHover.unhovered.fire();

            if (this._showTooltip) {
              this.view.removeAttribute("title");
            }
          }

          this.beforeHover = null;
        };

        HoverPlugin.prototype._onMouseOut = function () {
          if (this.beforeHover) this._onUnhovered(this.beforeHover);
        };

        return HoverPlugin;
      }();

      exports.HoverPlugin = HoverPlugin;
      module.exports = HoverPlugin;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Converter_1 = require("./Converter");

      exports.Converter = Converter_1.Converter;
    }, {
      "./Converter": 1
    }],
    4: [function (require, module, exports) {
      "use strict";

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return __assign.apply(this, arguments);
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.FallbackDialog = void 0;

      var akashic_hover_plugin_1 = require("@akashic-extension/akashic-hover-plugin");

      var HoverPluginRaw = require("@akashic-extension/akashic-hover-plugin/lib/HoverPlugin"); // Ugh! HoverPlugin が Akashic Engine 向けに中途半端に CommonJS で (module.exports = HoverPlugin と)
      // 定義されている関係で、 import すると TS の型と実体が合わない。無理やり解消する。
      // (import * as ... すると、 JS 的には HoverPlugin の実体が手に入るが、TS 上では namespace と誤認される)
      // さらにおそらく akashic-hover-plugin 側のバグで、型があっていないのでそれも無理やり合わせる。
      // (コンストラクタ第二引数が間違っている。実装上は any キャストして正しく使っている)


      var HoverPlugin = HoverPluginRaw;

      function drawCircle(rendr, centerX, centerY, radius, cssColor) {
        for (var y = centerY - radius | 0; y <= Math.ceil(centerY + radius); ++y) {
          var w = radius * Math.cos(Math.asin((centerY - y) / radius));
          rendr.fillRect(centerX - w, y, 2 * w, 1, cssColor);
        }
      }

      function makeSurface(w, h, drawer) {
        var s = g.game.resourceFactory.createSurface(Math.ceil(w), Math.ceil(h));
        var r = s.renderer();
        r.begin();
        drawer(r);
        r.end();
        return s;
      }

      function animate(e, motions) {
        var onEnd = new g.Trigger();
        var frameTime = 1000 / g.game.fps;
        var step = 0;
        var time = 0;
        var mot = motions[0];
        var ended = false;

        function update(delta) {
          time += delta;

          if (time > mot.duration) {
            ended = ++step >= motions.length;

            if (ended) {
              time = mot.duration;
              e.scene.onUpdate.addOnce(onEnd.fire, onEnd);
            } else {
              time -= mot.duration;
              mot = motions[step];
            }
          }

          var r = Math.min(1, time / mot.duration);
          var scale = mot.scale,
              opacity = mot.opacity;
          if (scale) e.scaleX = e.scaleY = scale[0] + (scale[1] - scale[0]) * r;
          if (opacity) e.opacity = opacity[0] + (opacity[1] - opacity[0]) * r;
          e.modified();
          return ended;
        }

        update(0);
        e.onUpdate.add(function () {
          return update(frameTime);
        });
        return onEnd;
      }

      var FallbackDialog =
      /** @class */
      function () {
        function FallbackDialog(name) {
          var _this = this;

          this.onEnd = new g.Trigger();
          this.isHoverPluginStarted = false;
          this.timer = null;
          if (!FallbackDialog.isSupported()) return;
          var game = g.game;
          var gameWidth = game.width,
              gameHeight = game.height;
          var baseWidth = 1280;
          var ratio = gameWidth / baseWidth;
          var titleFontSize = Math.round(32 * ratio);
          var fontSize = Math.round(28 * ratio);
          var lineMarginRate = 0.3;
          var lineHeightRate = 1 + lineMarginRate;
          var titleTopMargin = 80 * ratio;
          var titleBotMargin = 32 * ratio;
          var buttonTopMargin = 42 * ratio;
          var buttonWidth = 360 * ratio;
          var buttonHeight = 82 * ratio;
          var buttonBotMargin = 72 * ratio;
          var colorBlue = "#4a8de1";
          var colorWhite = "#fff";
          var dialogWidth = 960 * ratio | 0;
          var dialogHeight = titleTopMargin + titleFontSize * lineHeightRate * 2 + titleBotMargin + (fontSize + fontSize * lineHeightRate) + // 一行目のマージンは titleBotMargin に繰り込まれている
          buttonTopMargin + buttonHeight + buttonBotMargin | 0;
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.SansSerif,
            size: titleFontSize,
            fontWeight: g.FontWeight.Bold,
            fontColor: "#252525"
          });
          var surfSize = Math.ceil(32 * ratio) & ~1; // 切り上げて偶数に丸める

          var surfHalf = surfSize / 2;
          var dialogBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorWhite);
          });
          var btnActiveBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
          });
          var btnBgSurf = makeSurface(surfSize, surfSize, function (r) {
            drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
            drawCircle(r, surfHalf, surfHalf, 12 * ratio, colorWhite);
          });

          function makeLabel(param) {
            return new g.Label(__assign({
              scene: scene,
              font: font,
              local: true,
              textAlign: g.TextAlign.Center,
              widthAutoAdjust: false
            }, param));
          }

          var scene = this.scene = game.scene();
          var bg = this.bgRect = new g.FilledRect({
            scene: scene,
            local: true,
            width: gameWidth,
            height: gameHeight,
            cssColor: "rgba(0, 0, 0, 0.5)",
            touchable: true // 後ろの touch を奪って modal にする

          });
          var dialogPane = this.dialogPane = new g.Pane({
            scene: scene,
            local: true,
            width: dialogWidth,
            height: dialogHeight,
            anchorX: 0.5,
            anchorY: 0.5,
            x: game.width / 2 | 0,
            y: game.height / 2 | 0,
            backgroundImage: dialogBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, dialogBgSurf.width / 2 - 1),
            parent: bg
          });
          var dialogTextX = 80 * ratio | 0;
          var dialogTextWidth = 800 * ratio | 0;
          var y = 0;
          y += titleTopMargin + titleFontSize * lineMarginRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "このコンテンツは名前を利用します。",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "\u3042\u306A\u305F\u306F\u300C" + name + "\u300D\u3067\u3059\u3002",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize + titleBotMargin | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "ユーザ名で参加するには、",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "最新のニコニコ生放送アプリに更新してください。",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize + buttonTopMargin | 0;
          var buttonPane = new g.Pane({
            scene: scene,
            local: true,
            width: buttonWidth,
            height: buttonHeight,
            x: dialogWidth / 2,
            y: y + buttonHeight / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            backgroundImage: btnBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, btnBgSurf.width / 2 - 1),
            parent: scene,
            touchable: true
          });
          dialogPane.append(buttonPane);
          var buttonLabel = this.buttonLabel = makeLabel({
            x: 0,
            y: (buttonHeight - titleFontSize) / 2 - 5 * ratio,
            text: "OK (15)",
            fontSize: titleFontSize,
            width: buttonWidth,
            textColor: colorBlue
          });
          buttonPane.append(buttonLabel);

          var activateButton = function activateButton() {
            buttonPane.backgroundImage = btnActiveBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorWhite;
            buttonLabel.invalidate();
          };

          var deactivateButton = function deactivateButton() {
            buttonPane.backgroundImage = btnBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorBlue;
            buttonLabel.invalidate();
          };

          var h = akashic_hover_plugin_1.Converter.asHoverable(buttonPane);
          var animating = false;
          h.hovered.add(function () {
            activateButton();
            if (animating) return;
            animating = true;
            animate(buttonPane, [{
              duration: 16,
              scale: [1.0, 0.9]
            }, {
              duration: 16,
              scale: [0.9, 1.1]
            }, {
              duration: 33,
              scale: [1.1, 1.0]
            }]).add(function () {
              return animating = false;
            });
          });
          h.unhovered.add(deactivateButton);
          buttonPane.onPointDown.add(activateButton);
          buttonPane.onPointUp.add(function () {
            _this.end();
          });
          if (!game.operationPluginManager.plugins[FallbackDialog.HOVER_PLUGIN_OPCODE]) game.operationPluginManager.register(HoverPlugin, FallbackDialog.HOVER_PLUGIN_OPCODE);
        }

        FallbackDialog.isSupported = function () {
          // 縦横比 0.4 について: このダイアログは 16:9 の解像度で画面高さの約 65% (468px) を占有する。
          // すなわち画面高さが画面幅の約 37% 以下の場合画面に収まらない。余裕を見て 40% を下限とする。
          // (詳細な高さは下の dialogHeight の定義を参照せよ)
          return typeof window !== "undefined" && g.game.height / g.game.width >= 0.4 && HoverPlugin.isSupported();
        };

        FallbackDialog.prototype.start = function (remainingSeconds) {
          var _this = this;

          var game = g.game;
          var scene = this.scene;

          if (game.scene() !== scene) {
            // ないはずの異常系だが一応確認
            return;
          } // エッジケース考慮: hoverプラグインは必ず停止したいので、シーンが変わった時点で止めてしまう。
          // (mouseover契機で無駄にエンティティ検索したくない)


          game.onSceneChange.add(this._disablePluginOnSceneChange, this);
          game.operationPluginManager.start(FallbackDialog.HOVER_PLUGIN_OPCODE);
          this.isHoverPluginStarted = true;
          animate(this.dialogPane, [{
            duration: 100,
            scale: [0.5, 1.1],
            opacity: [0.5, 1.0]
          }, {
            duration: 100,
            scale: [1.1, 1.0],
            opacity: [1.0, 1.0]
          }]);
          scene.append(this.bgRect);
          scene.onUpdate.add(this._assureFrontmost, this);
          this.timer = scene.setInterval(function () {
            remainingSeconds -= 1;
            _this.buttonLabel.text = "OK (" + remainingSeconds + ")";

            _this.buttonLabel.invalidate();

            if (remainingSeconds <= 0) {
              _this.end();
            }
          }, 1000);
        };

        FallbackDialog.prototype.end = function () {
          var _this = this;

          if (this.timer) {
            this.scene.clearInterval(this.timer);
            this.timer = null;
          } // 厳密には下のアニメーション終了後に解除する方がよいが、
          // 途中でシーンが破棄されるエッジケースを想定してこの時点で止める。


          this.scene.onUpdate.remove(this._assureFrontmost, this);

          if (this.isHoverPluginStarted) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            this.isHoverPluginStarted = false;
          }

          animate(this.dialogPane, [{
            duration: 100,
            opacity: [1, 0],
            scale: [1, 0.8]
          }]);
          var t = animate(this.bgRect, [{
            duration: 100,
            opacity: [1, 0]
          }]);
          t.add(function () {
            var onEnd = _this.onEnd;
            _this.onEnd = null;

            _this.bgRect.destroy();

            _this.bgRect = null;
            _this.dialogPane = null;
            _this.scene = null;
            onEnd.fire();
          });
        };

        FallbackDialog.prototype._disablePluginOnSceneChange = function (scene) {
          if (scene !== this.scene) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            return true;
          }
        }; // フレーム終了時に確実に画面最前面に持ってくる


        FallbackDialog.prototype._assureFrontmost = function () {
          g.game._pushPostTickTask(this._doAssureFrontmost, this);
        };

        FallbackDialog.prototype._doAssureFrontmost = function () {
          var scene = this.scene;
          if (scene && g.game.scene() !== scene) return;
          if (scene.children[scene.children.length - 1] === this.bgRect) return;
          this.bgRect.remove();
          scene.append(this.bgRect);
        };

        FallbackDialog.HOVER_PLUGIN_OPCODE = -1000; // TODO: 定数予約

        return FallbackDialog;
      }();

      exports.FallbackDialog = FallbackDialog;
    }, {
      "@akashic-extension/akashic-hover-plugin": 3,
      "@akashic-extension/akashic-hover-plugin/lib/HoverPlugin": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.resolvePlayerInfo = void 0;

      var FallbackDialog_1 = require("./FallbackDialog");

      var DEFAULT_LIMIT_SECONDS = 15; // resolvePlayerInfo関数が2重で実行されてしまうことを防ぐためのフラグ

      var isCurrentResolvingPlayerInfo = false;
      /**
       * ユーザー情報の取得と通知を行う
       * @param opts ユーザ情報取得時のオプション
       * @param callback 指定された場合、playerInfo が取得成功・失敗した時点の次の local/non-local tick で呼び出される
       */

      exports.resolvePlayerInfo = function (opts, callback) {
        if (isCurrentResolvingPlayerInfo) {
          if (callback) {
            callback(new Error("Last processing has not yet been completed."));
          }

          return;
        }

        var limitSeconds = opts && opts.limitSeconds ? opts.limitSeconds : DEFAULT_LIMIT_SECONDS;

        var cb = function cb(info) {
          if (callback) {
            callback(null, info);
          }

          if (opts && opts.raises && (!info.userData || !info.userData.unnamed)) {
            g.game.raiseEvent(new g.PlayerInfoEvent({
              id: g.game.selfId,
              name: info.name,
              userData: info.userData
            }));
          }
        };

        var rpgAtsumaru = typeof window !== "undefined" ? window.RPGAtsumaru : undefined;

        if (rpgAtsumaru && rpgAtsumaru.user && rpgAtsumaru.user.getSelfInformation) {
          isCurrentResolvingPlayerInfo = true;
          rpgAtsumaru.user.getSelfInformation().then(function (data) {
            cb({
              name: data.name,
              userData: {
                accepted: true,
                premium: data.isPremium
              }
            });
            isCurrentResolvingPlayerInfo = false;
          }).catch(function (err) {
            if (callback) {
              callback(err);
            }

            isCurrentResolvingPlayerInfo = false;
          });
        } else if (g.game.external.coeLimited && g.game.external.coeLimited.startLocalSession && g.game.external.coeLimited.exitLocalSession) {
          isCurrentResolvingPlayerInfo = true;
          var sessionId_1 = g.game.playId + "__player-info-resolver";
          var scene_1 = g.game.scene();
          var timeoutId_1 = scene_1.setTimeout(function () {
            timeoutId_1 = null; // NOTE: スキップ時は既に終了済みのローカルセッション自体が起動せず messageHandler() も呼ばれなるため、
            // ここで cb() を呼ばないとコンテンツ側がコールバックをいつまでも待ってしまう状態になってしまう

            cb({
              name: null,
              userData: {
                accepted: false,
                premium: false
              }
            }); // NOTE: リアルタイム視聴の場合、大半のケースではこちらのパスには到達しないはず (仮に到達しても同一セッションIDの COE#exitSession() が呼ばれるのみ)
            // 追っかけ再生またはタイムシフトによる視聴においては、 player-info-resolver の自発終了よりも先に以下の exitLocalSession() を呼ぶことで
            // 「スキップ中のセッション起動を抑止する」というプラットフォーム側の機能を有効にしている

            g.game.external.coeLimited.exitLocalSession(sessionId_1, {
              needsResult: true
            });
            isCurrentResolvingPlayerInfo = false;
          }, (limitSeconds + 1) * 1000); // NOTE: 読み込みなどを考慮して 1 秒のバッファを取る

          var sessionParameters = {
            type: "start",
            parameters: {
              limitSeconds: limitSeconds
            }
          };
          g.game.external.coeLimited.startLocalSession({
            sessionId: sessionId_1,
            applicationName: "player-info-resolver",
            localEvents: [[32, 0, ":akashic", sessionParameters]],
            messageHandler: function messageHandler(message) {
              // TODO 引数からエラーを取得できるようになったら、異常系の処理も行う
              if (timeoutId_1 === null) {
                return;
              }

              scene_1.clearTimeout(timeoutId_1);
              cb(message.result);
              isCurrentResolvingPlayerInfo = false;
            }
          });
        } else if (FallbackDialog_1.FallbackDialog.isSupported()) {
          var name_1 = "ゲスト" + (Math.random() * 1000 | 0);
          var dialog = new FallbackDialog_1.FallbackDialog(name_1);
          dialog.start(limitSeconds);
          dialog.onEnd.addOnce(function () {
            cb({
              name: name_1,
              userData: {
                accepted: false,
                premium: false
              }
            });
            isCurrentResolvingPlayerInfo = false;
          });
        } else {
          cb({
            name: "",
            userData: {
              accepted: false,
              premium: false,
              unnamed: true
            }
          });
        }
      };
    }, {
      "./FallbackDialog": 4
    }],
    6: [function (require, module, exports) {
      var resolvePlayerInfo = require("@akashic-extension/resolve-player-info").resolvePlayerInfo;

      function main(param) {
        // 初期処理
        var gameMasterID = null;
        g.game.join.addOnce(function (e) {
          gameMasterID = e.player.id;
        });
        var quizid = "";
        var quizname = "";
        var quiz_num = 0;
        var quiz_num_now = 0;
        var your_score = 0;
        var your_ans = [];
        var quiz_ans = [];
        var now_select;
        var quiz_join_member = 0;
        var yourjoinstatus = "no";
        var playersTable = {};
        g.game.onPlayerInfo.add(function (ev) {
          var player = ev.player;
          playersTable[player.id] = {
            name: player.name,
            score: 0
          };
          quiz_join_member = quiz_join_member + 1;
        });
        var gamestatus = "GameMasterWaiting";
        var font = new g.DynamicFont({
          game: g.game,
          fontFamily: "sans-serif",
          size: 50
        }); //クイズ追加時記載場所

        var quizids = ["9", "000000", "000001", "000002", "000003", "252539"];

        function quiz_setting() {
          if (quizid == "9") {
            quizid = "9";
            quizname = "debug";
            quiz_num = 1;
            quiz_ans = ["a"];
          }

          if (quizid == "252539") {
            quizid = "252539";
            quizname = "超検定2021テストプレイ";
            quiz_num = 5;
            quiz_ans = ["a", "c", "d", "a", "a"];
          }

          if (quizid == "000000") {
            quizid = "000000";
            quizname = "テスト問題00";
            quiz_num = 5;
            quiz_ans = ["a", "d", "b", "a", "c"];
          }

          if (quizid == "000001") {
            quizid = "000001";
            quizname = "テスト問題01";
            quiz_num = 5;
            quiz_ans = ["a", "c", "b", "b", "a"];
          }

          if (quizid == "000002") {
            quizid = "000002";
            quizname = "テスト問題02";
            quiz_num = 10;
            quiz_ans = ["a", "c", "b", "b", "a", "a", "c", "b", "d", "d"];
          }

          if (quizid == "000003") {
            quizid = "000003";
            quizname = "テスト問題03";
            quiz_num = 20;
            quiz_ans = ["d", "c", "a", "a", "a", "b", "d", "d", "c", "a", "a", "c", "c", "d", "d", "c", "b", "c", "c", "a"];
          }
        } //ここまで
        //==============
        //毎フレーム処理


        function mainLoop() {
          if (gamestatus == "GameMasterWaiting") {
            if (gameMasterID != null) {
              gamestatus = "EntryUserWaiting";
              onGameMasterArrive();
            }
          }

          if (gamestatus == "EntryUserWaiting") {//todo?
          }

          if (gamestatus == "GameStart") {//todo
          }

          if (gamestatus == "result") {//???
          }
        } //==============
        //待機シーン


        var waiting_scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: ["logo", "but_sanka", "but_shimekiri", "popup_uketsuke", "but_ok", "massage_taiki", "but_id", "key_0", "key_1", "key_2", "key_3", "key_4", "key_5", "key_6", "key_7", "key_8", "key_9", "but_s_ok", "but_s_back", "popup_startcheck", "but_yes", "but_no"]
        });
        g.game.pushScene(waiting_scene);
        waiting_scene.onLoad.add(function () {
          var underline = new g.FilledRect({
            scene: waiting_scene,
            width: g.game.width,
            height: 50 / 1.5,
            cssColor: "#2ea7e0",
            x: 0,
            y: 985 / 1.5
          });
          var logo = new g.Sprite({
            scene: waiting_scene,
            src: waiting_scene.asset.getImageById("logo"),
            scaleX: 0.667,
            scaleY: 0.667,
            x: 100 / 1.5,
            y: 675 / 1.5
          });
          waiting_scene.append(underline);
          waiting_scene.append(logo);
        });

        function onGameMasterArrive() {
          if (g.game.selfId == gameMasterID) {
            var entryclose_but = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("but_shimekiri"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1350 / 1.5,
              y: 785 / 1.5,
              local: true,
              touchable: true
            });
            var popup_quiz_start = new g.E({
              scene: waiting_scene
            });
            var popup_quiz_start_dialog = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("popup_startcheck"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 320 / 1.5,
              y: 180 / 1.5,
              local: true
            });
            var popup_yes_but = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("but_yes"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1075 / 1.5,
              y: 700 / 1.5,
              local: true,
              touchable: true
            });
            var popup_no_but = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("but_no"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 520 / 1.5,
              y: 700 / 1.5,
              local: true,
              touchable: true
            });
            popup_quiz_start.append(popup_quiz_start_dialog);
            popup_quiz_start.append(popup_yes_but);
            popup_quiz_start.append(popup_no_but);
            var idinput_but = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("but_id"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1350 / 1.5,
              y: 215 / 1.5,
              local: true,
              touchable: true
            });
            var assistant_disp = new g.Label({
              scene: waiting_scene,
              font: font,
              text: "IDを入力してください",
              fontSize: 50 / 1.5,
              textColor: "black",
              x: 25 / 1.5,
              y: 1000 / 1.5
            });
            var tenkey = new g.E({
              scene: waiting_scene
            });
            var tenkey_0 = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("key_0"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 806 / 1.5,
              y: 860 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_1 = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("key_1"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 480 / 1.5,
              y: 635 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_2 = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("key_2"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 806 / 1.5,
              y: 635 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_3 = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("key_3"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1133 / 1.5,
              y: 635 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_4 = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("key_4"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 480 / 1.5,
              y: 415 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_5 = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("key_5"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 806 / 1.5,
              y: 415 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_6 = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("key_6"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1133 / 1.5,
              y: 415 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_7 = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("key_7"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 480 / 1.5,
              y: 195 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_8 = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("key_8"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 806 / 1.5,
              y: 195 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_9 = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("key_9"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1133 / 1.5,
              y: 195 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_ok = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("but_s_ok"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1550 / 1.5,
              y: 835 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_back = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("but_s_back"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 70 / 1.5,
              y: 835 / 1.5,
              local: true,
              touchable: true
            });
            var tenkey_disp = new g.Label({
              scene: waiting_scene,
              font: font,
              text: "",
              fontSize: 110 / 1.5,
              textColor: "black",
              x: 630 / 1.5,
              y: 50 / 1.5
            });
            tenkey.append(tenkey_0);
            tenkey.append(tenkey_1);
            tenkey.append(tenkey_2);
            tenkey.append(tenkey_3);
            tenkey.append(tenkey_4);
            tenkey.append(tenkey_5);
            tenkey.append(tenkey_6);
            tenkey.append(tenkey_7);
            tenkey.append(tenkey_8);
            tenkey.append(tenkey_9);
            tenkey.append(tenkey_ok);
            tenkey.append(tenkey_back);
            tenkey.append(tenkey_disp);
            tenkey_0.pointDown.add(function () {
              quizid = quizid + "0";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
            });
            tenkey_1.pointDown.add(function () {
              quizid = quizid + "1";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
            });
            tenkey_2.pointDown.add(function () {
              quizid = quizid + "2";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
            });
            tenkey_3.pointDown.add(function () {
              quizid = quizid + "3";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
            });
            tenkey_4.pointDown.add(function () {
              quizid = quizid + "4";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
            });
            tenkey_5.pointDown.add(function () {
              quizid = quizid + "5";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
            });
            tenkey_6.pointDown.add(function () {
              quizid = quizid + "6";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
            });
            tenkey_7.pointDown.add(function () {
              quizid = quizid + "7";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
            });
            tenkey_8.pointDown.add(function () {
              quizid = quizid + "8";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
            });
            tenkey_9.pointDown.add(function () {
              quizid = quizid + "9";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
            });
            popup_yes_but.pointDown.add(function () {
              if (quizids.includes(quizid)) {
                waiting_scene.remove(popup_quiz_start);
                g.game.raiseEvent(new g.MessageEvent({
                  message: "EntryClosed"
                }));
              } else {
                console.warn("問題が存在しません");
              }
            });
            popup_no_but.pointDown.add(function () {
              waiting_scene.remove(popup_quiz_start);
              waiting_scene.append(entryclose_but);
              waiting_scene.append(idinput_but);
            });
            tenkey_ok.pointDown.add(function () {
              waiting_scene.remove(tenkey);
              waiting_scene.append(entryclose_but);
              waiting_scene.append(idinput_but);

              if (quizids.includes(quizid)) {
                quiz_setting();
              } else {
                quizname = "問題が存在しません";
              }

              assistant_disp.text = quizid + "：" + quizname;
              assistant_disp.invalidate();
              waiting_scene.append(assistant_disp);
            });
            tenkey_back.pointDown.add(function () {
              waiting_scene.remove(tenkey);
              waiting_scene.append(entryclose_but);
              waiting_scene.append(idinput_but);
              quizid = "";
            }); //gamemaster

            waiting_scene.append(entryclose_but);
            waiting_scene.append(idinput_but);
            waiting_scene.append(assistant_disp);
            idinput_but.pointDown.add(function () {
              quizid = "";
              tenkey_disp.text = quizid;
              tenkey_disp.invalidate();
              waiting_scene.remove(entryclose_but);
              waiting_scene.remove(idinput_but);
              waiting_scene.remove(assistant_disp);
              waiting_scene.append(tenkey);
            });
            entryclose_but.pointDown.add(function () {
              waiting_scene.remove(entryclose_but);
              waiting_scene.remove(idinput_but);
              waiting_scene.append(popup_quiz_start);
            });
          } else {
            var entry_but = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("but_sanka"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1350 / 1.5,
              y: 785 / 1.5,
              local: true,
              touchable: true
            });
            var popup_entry = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("popup_uketsuke"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 320 / 1.5,
              y: 180 / 1.5,
              local: true
            });
            var popup_entry_ok = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("but_ok"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 740 / 1.5,
              y: 700 / 1.5,
              local: true,
              touchable: true
            });
            var waiting = new g.Sprite({
              scene: waiting_scene,
              src: waiting_scene.asset.getImageById("massage_taiki"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1435 / 1.5,
              y: 830 / 1.5,
              local: true
            }); //user

            waiting_scene.append(entry_but);
            entry_but.pointDown.add(function () {
              waiting_scene.remove(entry_but);
              waiting_scene.append(waiting);
              resolvePlayerInfo({
                raises: true
              });
              yourjoinstatus = "yes";
              waiting_scene.append(popup_entry);
              waiting_scene.append(popup_entry_ok);
            });
            popup_entry_ok.pointDown.add(function () {
              waiting_scene.remove(popup_entry);
              waiting_scene.remove(popup_entry_ok);
            });
          }
        }

        waiting_scene.update.add(mainLoop);
        waiting_scene.message.add(function (ev) {
          if (ev.data.message == "EntryClosed") {
            gamestatus = "GameStart";
            QuizStart();
          }
        }); //==============

        function QuizStart() {
          //ゲームシーン
          var game_scene = new g.Scene({
            game: g.game,
            assetIds: ["joinmember", "quiz_next", "quiz_now", "quiz_prev", "quiz_selector_a", "quiz_selector_b", "quiz_selector_c", "quiz_selector_d", "quiz_select_border_g", "quiz_wait", "waiting", "no_join_message", "but_happyou", "quiz_open", "select"]
          });
          g.game.replaceScene(game_scene);
          game_scene.onLoad.add(function () {
            quiz_setting();
            var status = new g.E({
              scene: game_scene
            });
            var status_wait = new g.Sprite({
              scene: game_scene,
              src: game_scene.asset.getImageById("waiting"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1417 / 1.5,
              y: 30 / 1.5
            });
            var status_member = new g.Sprite({
              scene: game_scene,
              src: game_scene.asset.getImageById("joinmember"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1417 / 1.5,
              y: 30 / 1.5
            });
            var status_member_num = new g.Label({
              scene: game_scene,
              font: font,
              text: quiz_join_member + "",
              fontSize: 75 / 1.5,
              textColor: "white",
              x: 1545 / 1.5,
              y: 52 / 1.5
            });
            var status_now_quiz = new g.Label({
              scene: game_scene,
              font: font,
              text: quiz_num_now + " / " + quiz_num,
              fontSize: 75 / 1.5,
              textColor: "black",
              x: 310 / 1.5,
              y: 50 / 1.5
            });
            status_member_num.modified();
            status.append(status_member);
            status.append(status_member_num);
            status.append(status_wait);
            status.append(status_now_quiz);
            game_scene.append(status);

            var open_member_counter = function open_member_counter() {
              status.remove(status_wait);
            };

            setTimeout(open_member_counter, 2000);
            var quiz_dialog = new g.E({
              scene: game_scene
            });
            var quiz_selector = new g.E({
              scene: game_scene
            });
            var open_result_but = new g.Sprite({
              scene: game_scene,
              src: game_scene.asset.getImageById("but_happyou"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1350 / 1.5,
              y: 785 / 1.5,
              local: true,
              touchable: true
            });
            open_result_but.pointDown.add(function () {
              g.game.raiseEvent(new g.MessageEvent({
                message: "open_result"
              }));
            });

            if (g.game.selfId == gameMasterID) {
              g.game.raiseEvent(new g.MessageEvent({
                message: "id:" + quizid
              }));
              var quiz_next_but = new g.Sprite({
                scene: game_scene,
                src: game_scene.asset.getImageById("quiz_next"),
                scaleX: 0.667,
                scaleY: 0.667,
                x: 1550 / 1.5,
                y: 835 / 1.5,
                local: true,
                touchable: true
              });
              var quiz_prev_but = new g.Sprite({
                scene: game_scene,
                src: game_scene.asset.getImageById("quiz_prev"),
                scaleX: 0.667,
                scaleY: 0.667,
                x: 70 / 1.5,
                y: 835 / 1.5,
                local: true,
                touchable: true
              });
              quiz_dialog.append(quiz_next_but);
              quiz_dialog.append(quiz_prev_but);
              game_scene.append(quiz_dialog);
              quiz_next_but.pointDown.add(function () {
                g.game.raiseEvent(new g.MessageEvent({
                  message: "AnswerClosed"
                }));
              });
            } else {
              if (yourjoinstatus == "yes") {
                var quiz_waiting = new g.Sprite({
                  scene: game_scene,
                  src: game_scene.asset.getImageById("quiz_wait"),
                  scaleX: 0.667,
                  scaleY: 0.667,
                  x: 432 / 1.5,
                  y: 820 / 1.5,
                  local: true
                });
                var quiz_selector_a = new g.Sprite({
                  scene: game_scene,
                  src: game_scene.asset.getImageById("quiz_selector_a"),
                  scaleX: 0.667,
                  scaleY: 0.667,
                  x: 60 / 1.5,
                  y: 665 / 1.5,
                  local: true,
                  touchable: true
                });
                var quiz_selector_b = new g.Sprite({
                  scene: game_scene,
                  src: game_scene.asset.getImageById("quiz_selector_b"),
                  scaleX: 0.667,
                  scaleY: 0.667,
                  x: 975 / 1.5,
                  y: 665 / 1.5,
                  local: true,
                  touchable: true
                });
                var quiz_selector_c = new g.Sprite({
                  scene: game_scene,
                  src: game_scene.asset.getImageById("quiz_selector_c"),
                  scaleX: 0.667,
                  scaleY: 0.667,
                  x: 60 / 1.5,
                  y: 865 / 1.5,
                  local: true,
                  touchable: true
                });
                var quiz_selector_d = new g.Sprite({
                  scene: game_scene,
                  src: game_scene.asset.getImageById("quiz_selector_d"),
                  scaleX: 0.667,
                  scaleY: 0.667,
                  x: 975 / 1.5,
                  y: 865 / 1.5,
                  local: true,
                  touchable: true
                });
                var quiz_select_border = new g.Sprite({
                  scene: game_scene,
                  src: game_scene.asset.getImageById("quiz_select_border_g"),
                  scaleX: 0.667,
                  scaleY: 0.667,
                  local: true
                });
                quiz_selector.append(quiz_selector_a);
                quiz_selector.append(quiz_selector_b);
                quiz_selector.append(quiz_selector_c);
                quiz_selector.append(quiz_selector_d);
                game_scene.append(quiz_waiting);
                quiz_selector_a.pointDown.add(function () {
                  game_scene.remove(quiz_select_border);
                  quiz_select_border.x = quiz_selector_a.x;
                  quiz_select_border.y = quiz_selector_a.y;
                  quiz_select_border.modified();
                  game_scene.append(quiz_select_border);
                  now_select = "a";
                  game_scene.asset.getAudioById("select").play();
                });
                quiz_selector_b.pointDown.add(function () {
                  game_scene.remove(quiz_select_border);
                  quiz_select_border.x = quiz_selector_b.x;
                  quiz_select_border.y = quiz_selector_b.y;
                  quiz_select_border.modified();
                  game_scene.append(quiz_select_border);
                  now_select = "b";
                  game_scene.asset.getAudioById("select").play();
                });
                quiz_selector_c.pointDown.add(function () {
                  game_scene.remove(quiz_select_border);
                  quiz_select_border.x = quiz_selector_c.x;
                  quiz_select_border.y = quiz_selector_c.y;
                  quiz_select_border.modified();
                  game_scene.append(quiz_select_border);
                  now_select = "c";
                  game_scene.asset.getAudioById("select").play();
                });
                quiz_selector_d.pointDown.add(function () {
                  game_scene.remove(quiz_select_border);
                  quiz_select_border.x = quiz_selector_d.x;
                  quiz_select_border.y = quiz_selector_d.y;
                  quiz_select_border.modified();
                  game_scene.append(quiz_select_border);
                  now_select = "d";
                  game_scene.asset.getAudioById("select").play();
                });
                game_scene.message.add(function (ev) {
                  if (ev.data.message == "AnswerClosed") {
                    if (quiz_num_now == 0) {
                      game_scene.remove(quiz_waiting);
                      game_scene.append(quiz_selector);
                    } else {
                      game_scene.remove(quiz_select_border);
                      save_anser();
                    }
                  }
                });
              } else {
                var no_join_message = new g.Sprite({
                  scene: game_scene,
                  src: game_scene.asset.getImageById("no_join_message"),
                  scaleX: 0.667,
                  scaleY: 0.667,
                  x: 432 / 1.5,
                  y: 820 / 1.5,
                  local: true
                });
                game_scene.append(no_join_message);

                var no_join_status_message = function no_join_status_message() {
                  game_scene.remove(no_join_message);
                };

                setTimeout(no_join_status_message, 7500);
              }
            }

            game_scene.message.add(function (ev) {
              //クイズ問題追加時記載場所
              if (ev.data.message == "id:9") {
                quizid = "9";
                quiz_setting();
                status_now_quiz.invalidate();
              }

              if (ev.data.message == "id:252539") {
                quizid = "252539";
                quiz_setting();
                status_now_quiz.invalidate();
              }

              if (ev.data.message == "id:000000") {
                quizid = "000000";
                quiz_setting();
                status_now_quiz.invalidate();
              }

              if (ev.data.message == "id:000001") {
                quizid = "000001";
                quiz_setting();
                status_now_quiz.invalidate();
              }

              if (ev.data.message == "id:000002") {
                quizid = "000002";
                quiz_setting();
                status_now_quiz.invalidate();
              }

              if (ev.data.message == "id:000003") {
                quizid = "000003";
                quiz_setting();
                status_now_quiz.invalidate();
              }

              if (ev.data.message == "AnswerClosed") {
                quiz_num_now = quiz_num_now + 1;
                status_now_quiz.text = quiz_num_now + " / " + quiz_num;
                status_now_quiz.invalidate();
                game_scene.asset.getAudioById("quiz_open").play();

                if (quiz_num_now > quiz_num) {
                  game_scene.append(status_wait);
                  status.remove(status_now_quiz);

                  if (g.game.selfId == gameMasterID) {
                    game_scene.remove(quiz_dialog);
                    game_scene.append(open_result_but);
                  } else {
                    if (yourjoinstatus == "yes") {
                      game_scene.remove(quiz_selector);
                    }
                  }
                }
              }

              if (ev.data.message == "open_result") {
                check_answer();
              }
            });
          });
          game_scene.update.add(mainLoop);
        }

        function save_anser() {
          your_ans[quiz_num_now - 1] = now_select;
        }

        ;

        function check_answer() {
          var check_answer_scene = new g.Scene({
            game: g.game,
            assetIds: ["result_header", "result_o", "result_x", "but_ranking"]
          });
          g.game.replaceScene(check_answer_scene);
          check_answer_scene.onLoad.add(function () {
            var result_header = new g.Sprite({
              scene: check_answer_scene,
              src: check_answer_scene.asset.getImageById("result_header"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 5 / 1.5,
              y: 28 / 1.5
            });
            var result_header_label = new g.Label({
              scene: check_answer_scene,
              local: true,
              font: font,
              text: "",
              fontSize: 50,
              textColor: "black",
              x: g.game.width / 1.75,
              y: 50 / 1.5
            });

            if (g.game.selfId == gameMasterID) {
              //GM
              result_header_label.text = "結果発表中です。";
              var result_ranking_but = new g.Sprite({
                scene: check_answer_scene,
                src: check_answer_scene.asset.getImageById("but_ranking"),
                scaleX: 0.667,
                scaleY: 0.667,
                x: 1350 / 1.5,
                y: 785 / 1.5,
                local: true,
                touchable: true
              });
              result_ranking_but.pointDown.add(function () {
                g.game.raiseEvent(new g.MessageEvent({
                  message: "open_ranking"
                }));
              });
              check_answer_scene.append(result_ranking_but); //正答率受信

              check_answer_scene.message.add(function (ev) {//TODO 正解した情報を受信してその問題の正答率を出したい
              });
            } else {
              if (yourjoinstatus == "yes") {
                //参加者
                result_header_label.text = playersTable[g.game.selfId].name + "さんの採点結果"; //採点発表

                var result_panel = new g.E({
                  scene: check_answer_scene,
                  touchable: true,
                  local: true
                });

                for (var i = 0; i < quiz_num; i++) {
                  var answer_panel = new g.FilledRect({
                    scene: check_answer_scene,
                    cssColor: "white",
                    width: 330,
                    height: 360,
                    scaleX: 0.667,
                    scaleY: 0.667,
                    parrent: result_panel,
                    local: true
                  });
                  var answer_quiz_label = new g.Label({
                    scene: check_answer_scene,
                    font: font,
                    text: "第" + (i + 1) + "問",
                    fontSize: 65 / 1.5,
                    textColor: "black",
                    parrent: result_panel,
                    local: true
                  });

                  if (your_ans[i] == quiz_ans[i]) {
                    var answer_ox = new g.Sprite({
                      scene: check_answer_scene,
                      src: check_answer_scene.asset.getImageById("result_o"),
                      scaleX: 0.667,
                      scaleY: 0.667,
                      parrent: result_panel,
                      local: true
                    }); //スコア加算・GM用正答率送信

                    your_score = your_score + 100 / quiz_num;
                    g.game.raiseEvent(new g.MessageEvent({
                      o_answer: i
                    }));
                  } else {
                    var answer_ox = new g.Sprite({
                      scene: check_answer_scene,
                      src: check_answer_scene.asset.getImageById("result_x"),
                      scaleX: 0.600,
                      scaleY: 0.600,
                      parrent: result_panel,
                      local: true
                    });
                  }

                  ; //Y座標指定

                  if (0 <= i && i <= 4) {
                    answer_panel.y = 233 / 1.5;
                    answer_quiz_label.y = 251 / 1.5;
                    answer_ox.y = 353 / 1.5;
                  }

                  if (5 <= i && i <= 9) {
                    answer_panel.y = 631 / 1.5;
                    answer_quiz_label.y = 658 / 1.5;
                    answer_ox.y = 751 / 1.5;
                  }

                  if (10 <= i && i <= 14) {
                    answer_panel.y = 1047 / 1.5;
                    answer_quiz_label.y = 1065 / 1.5;
                    answer_ox.y = 1167 / 1.5;
                  }

                  if (15 <= i && i <= 19) {
                    answer_panel.y = 1463 / 1.5;
                    answer_quiz_label.y = 1481 / 1.5;
                    answer_ox.y = 1583 / 1.5;
                  } //X座標指定


                  if (i % 5 == 0) {
                    answer_panel.x = 90 / 1.5;
                    answer_quiz_label.x = 156 / 1.5;
                    answer_ox.x = 145 / 1.5;
                  }

                  if (i % 5 == 1) {
                    answer_panel.x = 446 / 1.5;
                    answer_quiz_label.x = 512 / 1.5;
                    answer_ox.x = 500 / 1.5;
                  }

                  if (i % 5 == 2) {
                    answer_panel.x = 798 / 1.5;
                    answer_quiz_label.x = 864 / 1.5;
                    answer_ox.x = 853 / 1.5;
                  }

                  if (i % 5 == 3) {
                    answer_panel.x = 1157 / 1.5;
                    answer_quiz_label.x = 1223 / 1.5;
                    answer_ox.x = 1221 / 1.5;
                  }

                  if (i % 5 == 4) {
                    answer_panel.x = 1512 / 1.5;
                    answer_quiz_label.x = 1578 / 1.5;
                    answer_ox.x = 1566 / 1.5;
                  } //reset


                  answer_panel.modified();
                  answer_ox.modified();
                  answer_quiz_label.invalidate();
                  result_panel.append(answer_panel);
                  result_panel.append(answer_ox);
                  result_panel.append(answer_quiz_label);
                  result_panel.modified();
                }

                ;
                check_answer_scene.append(result_panel); //スコア送信

                g.game.raiseEvent(new g.MessageEvent({
                  score: your_score
                }));

                if (quiz_num >= 10) {
                  result_panel.onUpdate.add(function () {
                    --result_panel.y;
                    result_panel.modified();

                    if (result_panel.y < -800) {
                      result_panel.y = 100;
                      result_panel.modified();
                    }
                  });
                }
              } else {
                //未参加者
                result_header_label.text = "結果発表中です。";
              }
            }

            result_header_label.invalidate();
            result_header.append(result_header_label);
            check_answer_scene.append(result_header); //スコア受信・移動

            check_answer_scene.message.add(function (ev) {
              if (ev.data.score) {
                playersTable[ev.player.id].score = ev.data.score;
              }

              if (ev.data.message == "open_ranking") {
                result_ranking();
              }
            });
          });
        }

        function result_ranking() {
          var ranking_scene = new g.Scene({
            game: g.game,
            assetIds: ["ranking_bg", "joinmember", "font", "font_glyphs"]
          });
          g.game.replaceScene(ranking_scene);
          ranking_scene.onLoad.add(function () {
            // 背景etc
            var ranking_bg = new g.Sprite({
              scene: ranking_scene,
              src: ranking_scene.asset.getImageById("ranking_bg"),
              scaleX: 0.667,
              scaleY: 0.667
            });
            var join_member_bg = new g.Sprite({
              scene: ranking_scene,
              src: ranking_scene.asset.getImageById("joinmember"),
              scaleX: 0.667,
              scaleY: 0.667,
              x: 1417 / 1.5,
              y: 30 / 1.5
            });
            var join_member_label = new g.Label({
              scene: ranking_scene,
              font: font,
              text: quiz_join_member + "",
              fontSize: 75 / 1.5,
              textColor: "white",
              x: 1545 / 1.5,
              y: 52 / 1.5
            });
            ranking_scene.append(ranking_bg);
            ranking_scene.append(join_member_bg);
            ranking_scene.append(join_member_label); // ビットマップフォントを生成

            var fontAsset = g.game.scene().asset.getImageById("font");
            var fontGlyphAsset = g.game.scene().asset.getTextById("font_glyphs");
            var glyphInfo = JSON.parse(fontGlyphAsset.data);
            var scorefont = new g.BitmapFont({
              src: fontAsset,
              glyphInfo: glyphInfo
            }); //あなたの点数

            var yourname = "あなたは参加していません";
            var yourscore = 0;

            if (playersTable[g.game.selfId]) {
              yourname = playersTable[g.game.selfId].name + " さん";
              yourscore = playersTable[g.game.selfId].score;
            }

            var ranking_your_name_label = new g.Label({
              scene: ranking_scene,
              font: font,
              text: yourname,
              fontSize: 65 / 1.5,
              textColor: "black",
              x: 350 / 1.5,
              y: 945 / 1.5
            });
            var ranking_your_score_label = new g.Label({
              scene: ranking_scene,
              font: scorefont,
              text: yourscore + "",
              fontSize: 100,
              textColor: "red",
              scaleX: 0.75,
              anchorX: 0.5,
              x: 1650 / 1.5,
              y: 935 / 1.5
            });
            ranking_scene.append(ranking_your_name_label);
            ranking_scene.append(ranking_your_score_label); //ランキング

            var ranking_topFive = Object.keys(playersTable).map(function (id) {
              return {
                score: playersTable[id],
                id: id
              };
            }).sort(function (a, b) {
              return b.score.score - a.score.score;
            }).slice(0, 5);

            if (ranking_topFive[0]) {
              var ranking_1st_name_label = new g.Label({
                scene: ranking_scene,
                font: font,
                text: ranking_topFive[0].score.name + " さん",
                fontSize: 65 / 1.5,
                textColor: "black",
                x: 350 / 1.5,
                y: 200 / 1.5
              });
              var ranking_1st_score_label = new g.Label({
                scene: ranking_scene,
                font: scorefont,
                text: ranking_topFive[0].score.score + "",
                fontSize: 100,
                textColor: "red",
                scaleX: 0.75,
                anchorX: 0.5,
                x: 1650 / 1.5,
                y: 190 / 1.5
              });
              ranking_scene.append(ranking_1st_name_label);
              ranking_scene.append(ranking_1st_score_label);
            }

            if (ranking_topFive[1]) {
              var ranking_2nd_name_label = new g.Label({
                scene: ranking_scene,
                font: font,
                text: ranking_topFive[1].score.name + " さん",
                fontSize: 65 / 1.5,
                textColor: "black",
                x: 350 / 1.5,
                y: 350 / 1.5
              });
              var ranking_2nd_score_label = new g.Label({
                scene: ranking_scene,
                font: scorefont,
                text: ranking_topFive[1].score.score + "",
                fontSize: 100,
                textColor: "red",
                scaleX: 0.75,
                anchorX: 0.5,
                x: 1650 / 1.5,
                y: 325 / 1.5
              });
              ranking_scene.append(ranking_2nd_name_label);
              ranking_scene.append(ranking_2nd_score_label);
            }

            if (ranking_topFive[2]) {
              var ranking_3rd_name_label = new g.Label({
                scene: ranking_scene,
                font: font,
                text: ranking_topFive[2].score.name + " さん",
                fontSize: 65 / 1.5,
                textColor: "black",
                x: 350 / 1.5,
                y: 500 / 1.5
              });
              var ranking_3rd_score_label = new g.Label({
                scene: ranking_scene,
                font: scorefont,
                text: ranking_topFive[2].score.score + "",
                fontSize: 100,
                textColor: "red",
                scaleX: 0.75,
                anchorX: 0.5,
                x: 1650 / 1.5,
                y: 475 / 1.5
              });
              ranking_scene.append(ranking_3rd_name_label);
              ranking_scene.append(ranking_3rd_score_label);
            }

            if (ranking_topFive[3]) {
              var ranking_4th_name_label = new g.Label({
                scene: ranking_scene,
                font: font,
                text: ranking_topFive[3].score.name + " さん",
                fontSize: 65 / 1.5,
                textColor: "black",
                x: 350 / 1.5,
                y: 650 / 1.5
              });
              var ranking_4th_score_label = new g.Label({
                scene: ranking_scene,
                font: scorefont,
                text: ranking_topFive[3].score.score + "",
                fontSize: 100,
                textColor: "red",
                scaleX: 0.75,
                anchorX: 0.5,
                x: 1650 / 1.5,
                y: 625 / 1.5
              });
              ranking_scene.append(ranking_4th_name_label);
              ranking_scene.append(ranking_4th_score_label);
            }

            if (ranking_topFive[4]) {
              var ranking_5th_name_label = new g.Label({
                scene: ranking_scene,
                font: font,
                text: ranking_topFive[4].score.name + " さん",
                fontSize: 65 / 1.5,
                textColor: "black",
                x: 350 / 1.5,
                y: 790 / 1.5
              });
              var ranking_5th_score_label = new g.Label({
                scene: ranking_scene,
                font: scorefont,
                text: ranking_topFive[4].score.score + "",
                fontSize: 100,
                textColor: "red",
                scaleX: 0.75,
                anchorX: 0.5,
                x: 1650 / 1.5,
                y: 775 / 1.5
              });
              ranking_scene.append(ranking_5th_name_label);
              ranking_scene.append(ranking_5th_score_label);
            }
          });
        } //==============

        /*
        多分残ってるTODO
        ・GM：正答率集計/描画
        */

      }

      module.exports = main;
    }, {
      "@akashic-extension/resolve-player-info": 5
    }]
  }, {}, [6])(6);
});